package com.csr.receive.core;

/**
 * User: cdp
 * Date: 2018/6/29
 * Time: 13:36
 */
public abstract class BaseServer implements CsrServer {

    public abstract void startServer();
}
