package com.csr.receive.core;

/**
 * User: cdp
 * Date: 2018/6/29
 * Time: 13:22
 */
public interface CsrServer {
    public void serverHandle();

}
