package com.csr.receive.model;

/**
 * User: cdp
 * Date: 2018/7/2
 * Time: 17:06
 */
public class UserBean {
    private int id;
    private String username;
    private String password;
    private double account;

    public UserBean(String username, String password, double account) {
        this.username = username;
        this.password = password;
        this.account = account;
    }

    public UserBean( String username, String password, int id,double account) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.account = account;
    }

    @Override
    public String toString() {
        return "UserBean{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", account=" + account +
                '}';
    }
}
